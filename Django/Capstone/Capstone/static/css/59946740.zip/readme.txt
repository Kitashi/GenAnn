

	FAARY - Quick Form Builder (c)2010 by Faary.com
	
	
	
	Instruction.
	==========================================
	
	
	Thanks for using FAARY Services!
	
	
	Your form structure is ready now, you can connect it to your own PHP script 
	which will make action which you need - send emails, adding to database, etc.
	
	
	If you need a full package, with PHP functions which will process your form
	and send email to your mailbox - please become Faary Member:
		
		-> http://www.faary.com/join.php
	
	
        
        

	Did you know...
	==========================================
	
	
	This form builder is also part of IzzyWebsite - CMS system,
	build your next website using IzzyWebsite: http://www.izzywebsite.com
    


	
	If you want to use this form later in our builder, please see "source.txt" file
	- you can open it in notepad, and copy contents to clipboard - then paste them on Faary.com,
	after you click GENERATE button, you will see your form in preview, so you can make any changes there.
        